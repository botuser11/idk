
function ChangeHTML(){
var oldParagraph=document.getElementById('Par1');
var newParagraph="This is a new paragraph, Paragraph 2";
oldParagraph.innerHTML=newParagraph;
}

